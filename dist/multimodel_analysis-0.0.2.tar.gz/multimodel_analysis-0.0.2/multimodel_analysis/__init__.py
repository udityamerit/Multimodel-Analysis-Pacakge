# Entry level code and import for Multi-Model Analysis

from .multimodel import MultiModelClassifier
from .multimodel import MultiModelRegressior

__version__ = '0.0.1'
__author__ = 'Uditya Narayan Tiwari'